import mongoose, { Schema, Document } from "mongoose";

export interface IUser extends Document {
  email: string;
  name: string;
  image: string;
  products: string[];
  createdAt: Date;
  location: String;
  rate: String;
  bio: String;
  deploy_name: String;
  theme: String;
}

const UserSchema = new Schema<IUser>({
  email: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  image: { type: String },
  products: [{ type: Schema.Types.ObjectId, ref: "Product" }],
  location: {
    type: String,
    default: "",
  },
  rate: {
    type: String,
    default: "",
  },
  bio: {
    type: String,
    default: "",
  },
  deploy_name: {
    type: String,
  },
  theme: {
    type: String,
    default: "0",
  },
  createdAt: { type: Date, default: Date.now },
});

export const User =
  mongoose.models.User || mongoose.model<IUser>("User", UserSchema);
