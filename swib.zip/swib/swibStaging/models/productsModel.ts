import mongoose from "mongoose";

const ProductSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  rank: { type: Number },
  name: { type: String, required: true },
  image: { type: String, default: "" },
  description: { type: String, required: true },
  link: { type: String, default: "" },
  duration: { type: String, default: "" },
  status: {
    type: String,
    enum: [
      "building",
      "active",
      "onHold",
      "discontinued",
      "working",
      "completed",
    ],
    default: "active",
  },
  revenue: {
    type: Number,
    default: 0,
  },

  createdAt: { type: Date, default: Date.now },
});

export const Product =
  mongoose.models.Product || mongoose.model("Product", ProductSchema);
