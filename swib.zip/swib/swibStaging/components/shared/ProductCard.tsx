"use client";
import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Trash2,
  Link,
  Flag,
  DollarSign,
  Edit2,
  Check,
  X,
  Upload,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Product } from "@/lib/types";
import toast from "react-hot-toast";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import axios from "axios";
import { useSession } from "next-auth/react";
import { useProducts } from "../providers/product-context";
import { get } from "node:http";

interface ProductCardProps {
  product: Product;
  onSuccess: () => void; // Callback to refresh the product list
}

export const ProductCard = ({ product, onSuccess }: ProductCardProps) => {
  const { data: session } = useSession();
  const [isEditing, setIsEditing] = useState(false);
  const [editedProduct, setEditedProduct] = useState(product);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const { getProducts } = useProducts();
  const [imagePreview, setImagePreview] = useState<string | null>(
    product.image || null
  );
  const [isLoading, setIsLoading] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        toast.error("Please upload an image file");
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image size should be less than 5MB");
        return;
      }

      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    try {
      setIsLoading(true);
      if (!editedProduct.name?.trim()) {
        toast.error("Product name is required");
        return;
      }

      const formData = new FormData();
      formData.append("name", editedProduct.name);
      formData.append("description", editedProduct.description || "");
      formData.append("duration", editedProduct.duration || "");
      formData.append("status", editedProduct.status || "active");
      formData.append("revenue", editedProduct.revenue?.toString() || "0");
      formData.append("link", editedProduct.link || "");

      if (selectedImage) {
        formData.append("image", selectedImage);
      }

      // Direct API call to update product
      await axios.put(
        `/api/products?email=${session?.user?.email}&productId=${product._id}`,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      toast.success("Product updated successfully");
      setIsEditing(false);
      setSelectedImage(null);
      getProducts();
      onSuccess(); // Refresh the product list
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Failed to update product");
      console.error("Update error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    try {
      setIsLoading(true);
      await axios.delete(
        `/api/products?email=${session?.user?.email}&productId=${product._id}`
      );
      toast.success("Product deleted successfully");
      getProducts();
      onSuccess(); // Refresh the product list
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Failed to delete product");
      console.error("Delete error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setEditedProduct(product);
    setIsEditing(false);
    setSelectedImage(null);
    setImagePreview(product.image || null);
  };

  if (isEditing) {
    return (
      <Card className="w-full bg-zinc-900">
        <CardHeader className="flex flex-row justify-between items-center">
          <div className="flex items-center gap-4 w-full">
            <Input
              value={editedProduct.name}
              onChange={(e) =>
                setEditedProduct({ ...editedProduct, name: e.target.value })
              }
              placeholder="Title"
              className="font-semibold"
              disabled={isLoading}
            />
            <Input
              value={editedProduct.duration}
              onChange={(e) =>
                setEditedProduct({ ...editedProduct, duration: e.target.value })
              }
              placeholder="Duration"
              className="w-32"
              disabled={isLoading}
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleSave}
              disabled={isLoading}
            >
              <Check className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleCancel}
              disabled={isLoading}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Icon</Label>
            <div className="flex flex-col items-center gap-4">
              {imagePreview ? (
                <div className="relative w-32 h-32">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="w-full h-full object-cover rounded-lg"
                  />
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    className="absolute bottom-2 right-2"
                    onClick={() => {
                      setSelectedImage(null);
                      setImagePreview(null);
                    }}
                    disabled={isLoading}
                  >
                    Remove
                  </Button>
                </div>
              ) : (
                <div className="w-32 h-32 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center">
                  <label className="cursor-pointer flex flex-col items-center">
                    <Upload className="w-8 h-8 text-gray-400" />
                    <span className="text-sm text-gray-500">Upload Image</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageChange}
                      disabled={isLoading}
                    />
                  </label>
                </div>
              )}
            </div>
          </div>
          <Textarea
            value={editedProduct.description}
            placeholder="Description"
            onChange={(e) =>
              setEditedProduct({
                ...editedProduct,
                description: e.target.value,
              })
            }
            disabled={isLoading}
          />
          <div className="flex justify-between items-center">
            <Select
              value={editedProduct.status}
              onValueChange={(value: string) =>
                setEditedProduct({
                  ...editedProduct,
                  status: value as
                    | "building"
                    | "active"
                    | "onHold"
                    | "discontinued"
                    | "working"
                    | "completed",
                })
              }
              disabled={isLoading}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="building">Building</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="onHold">On Hold</SelectItem>
                <SelectItem value="discontinued">Discontinued</SelectItem>
                <SelectItem value="working">Working</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={editedProduct.revenue}
              onChange={(e) =>
                setEditedProduct({
                  ...editedProduct,
                  revenue: Number(e.target.value),
                })
              }
              placeholder="Revenue"
              className="w-32"
              disabled={isLoading}
            />
          </div>
          <Input
            value={editedProduct.link}
            onChange={(e) =>
              setEditedProduct({ ...editedProduct, link: e.target.value })
            }
            placeholder="Link"
            disabled={isLoading}
          />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full bg-zinc-900">
      <CardHeader className="flex flex-row justify-between items-center">
        <div className="flex items-center gap-4">
          {product.image ? (
            <img
              src={product.image}
              alt={product.name}
              className="w-12 h-12 rounded object-cover"
            />
          ) : (
            <div className="w-12 h-12 bg-gray-200 rounded flex items-center justify-center">
              <Upload className="w-6 h-6 text-gray-400" />
            </div>
          )}
          <div>
            <h3 className="font-semibold">{product.name}</h3>
            <p className="text-sm text-gray-500">{product.duration}</p>
          </div>
        </div>
        <div className="flex gap-2">
          {product.link && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => window.open(product.link, "_blank")}
              disabled={isLoading}
            >
              <Link className="w-4 h-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsEditing(true)}
            disabled={isLoading}
          >
            <Edit2 className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleDelete}
            disabled={isLoading}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm mb-4">{product.description}</p>
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Flag className="w-4 h-4" />
            <span className="text-sm">{product.status}</span>
          </div>
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4" />
            <span className="text-sm">${product.revenue}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
