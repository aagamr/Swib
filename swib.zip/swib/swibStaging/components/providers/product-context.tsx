"use client";
import React, { createContext, useContext, useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { Product } from "@/lib/types";
import toast from "react-hot-toast";
import axios from "axios";

interface ProductContextType {
  products: Product[];
  getProducts: () => Promise<void>;
  addProduct: (product: FormData) => Promise<void>;
  updateProduct: (id: string, product: FormData) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  loading: boolean;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const ProductProvider = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const { data: session } = useSession();

  const fetchProducts = async () => {
    try {
      const res = await axios.get(
        `/api/products?email=${session?.user?.email}`
      );
      setProducts(res.data);
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Failed to fetch products");
    }
  };

  const addProduct = async (product: FormData) => {
    setLoading(true);
    try {
      await axios.post(`/api/products?email=${session?.user?.email}`, product, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      toast.success("Product added successfully");
      await fetchProducts();
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Failed to add product");
    } finally {
      setLoading(false);
    }
  };

  const updateProduct = async (id: string, product: FormData) => {
    setLoading(true);
    try {
      await axios.put(
        `/api/products?email=${session?.user?.email}&productId=${id}`,
        product,
        { headers: { "Content-Type": "multipart/form-data" } }
      );
      toast.success("Product updated successfully");
      await fetchProducts();
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Failed to update product");
    } finally {
      setLoading(false);
    }
  };

  const deleteProduct = async (id: string) => {
    setLoading(true);
    try {
      await axios.delete(
        `/api/products?email=${session?.user?.email}&productId=${id}`
      );
      toast.success("Product deleted successfully");
      await fetchProducts();
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Failed to delete product");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (session?.user?.email) {
      fetchProducts();
    }
  }, [session]);

  return (
    <ProductContext.Provider
      value={{
        products,
        getProducts: fetchProducts,
        addProduct,
        updateProduct,
        deleteProduct,
        loading,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context)
    throw new Error("useProducts must be used within ProductProvider");
  return context;
};
