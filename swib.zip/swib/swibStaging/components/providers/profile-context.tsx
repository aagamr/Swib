"use client";

import { createContext, useState, useContext, useEffect } from "react";
import { Profile, ProfileContextType, ProfileProviderProps } from "@/lib/types";
import { useSession } from "next-auth/react";

const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

export const ProfileProvider: React.FC<ProfileProviderProps> = ({
  children,
}) => {
  const { data: session } = useSession();
  const [profile, setProfile] = useState<Profile>({
    name: "",
    location: "",
    bio: "",
    rate: "",
    email: "",
    image: "",
    theme: "",
  });

  const fetchProfile = async () => {
    if (session?.user?.email) {
      try {
        const response = await fetch(`/api/user?email=${session.user.email}`);
        const userData = await response.json();

        setProfile({
          name: userData.name || "",
          location: userData.location || "",
          bio: userData.bio || "",
          rate: userData.rate || "",
          email: userData.email || "",
          deploy_name: userData.deploy_name || "",
          image: userData.image || "",
          theme: userData.theme || "0",
        });
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    }
  };
  useEffect(() => {
    fetchProfile();
  }, [session]);

  const updateProfile = async (field: keyof Profile, value: string) => {
    try {
      const response = await fetch("/api/user", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: profile.email,
          [field]: value,
        }),
      });

      if (response.ok) {
        setProfile((prev) => ({ ...prev, [field]: value }));
      }
    } catch (error) {
      console.error("Error updating profile:", error);
    }
  };

  return (
    <ProfileContext.Provider
      value={{
        profile,
        fetchProfile,
        updateProfile,
        onUpdate: async () => Promise.resolve(),
        onDelete: async () => Promise.resolve(),
      }}
    >
      {children}
    </ProfileContext.Provider>
  );
};

export const useProfile = (): ProfileContextType => {
  const context = useContext(ProfileContext);
  if (!context) {
    throw new Error("useProfile must be used within a ProfileProvider");
  }
  return context;
};
