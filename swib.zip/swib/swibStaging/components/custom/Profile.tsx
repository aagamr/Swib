"use client";
import { useSession } from "next-auth/react";
import Image from "next/image";
import React from "react";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Banknote, Mail, MapPin, Camera, Loader2 } from "lucide-react";
import { useProfile } from "../providers/profile-context";
import { Button } from "../ui/button";
import { LocalProfile } from "@/lib/types";
import toast from "react-hot-toast";
import Products from "./Products";

const Profile = () => {
  const [locationToggle, setLocationToggle] = React.useState(false);
  const [rateToggle, setRateToggle] = React.useState(false);
  const [mailToggle, setMailToggle] = React.useState(false);
  const [isUploading, setIsUploading] = React.useState(false);
  const [localProfile, setLocalProfile] = React.useState({
    name: "",
    location: "",
    bio: "",
    rate: "",
    email: "",
    image: "",
  });
  const [isDirty, setIsDirty] = React.useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const { data: session } = useSession();
  const { profile, updateProfile, fetchProfile } = useProfile();

  React.useEffect(() => {
    setLocalProfile(profile);
  }, [profile]);

  const handleChange = (field: keyof LocalProfile, value: string) => {
    setLocalProfile((prev) => ({ ...prev, [field]: value }));
    setIsDirty(true);
  };

  const handleImageClick = () => {
    if (!isUploading) {
      fileInputRef.current?.click();
    }
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size must be less than 5MB");
      return;
    }

    setIsUploading(true);
    const formData = new FormData();
    formData.append("email", profile.email);
    formData.append("image", file);

    try {
      const response = await fetch("/api/user", {
        method: "PATCH",
        body: formData,
      });

      if (response.ok) {
        const updatedUser = await response.json();
        handleChange("image", updatedUser.image);
        fetchProfile();
        toast.success("Profile picture updated successfully");
      } else {
        toast.error("Failed to update profile picture");
      }
    } catch (error) {
      toast.error("Error updating profile picture");
    } finally {
      setIsUploading(false);
    }
  };

  const handleSave = async () => {
    for (const [key, value] of Object.entries(localProfile)) {
      if (value !== profile[key as keyof LocalProfile] && key !== "image") {
        await updateProfile(key as keyof LocalProfile, value);
      }
    }
    setIsDirty(false);
    toast.success("Profile updated successfully");
  };

  if (!session?.user) return null;

  return (
    <div className="">
      <div className="w-full bg-zinc-900 p-4 rounded-lg flex flex-col gap-2">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="relative w-[50px] h-[50px]">
              <Image
                src={localProfile.image || "/default-profile.png"}
                alt="profile"
                fill
                className={`rounded-full border-2 border-gray-700 ${
                  isUploading ? "opacity-50" : ""
                }`}
                style={{ objectFit: "cover" }}
              />
              {isUploading && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <Loader2 className="w-6 h-6 animate-spin text-white" />
                </div>
              )}
            </div>
            <button
              onClick={handleImageClick}
              disabled={isUploading}
              className={`absolute bottom-0 right-0 p-1 bg-zinc-800 rounded-full transition-colors
                ${
                  isUploading
                    ? "cursor-not-allowed opacity-50"
                    : "hover:bg-zinc-700"
                }`}
            >
              <Camera className="w-4 h-4" />
            </button>
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept="image/*"
              onChange={handleImageChange}
              disabled={isUploading}
            />
          </div>
          <div className="w-full">
            <Input
              placeholder={session?.user?.name || "Enter your name"}
              value={localProfile.name}
              onChange={(e) => handleChange("name", e.target.value)}
            />
          </div>
        </div>

        <div className="mt-2">
          <Textarea
            rows={4}
            placeholder="Write something about you..."
            className="bg-zinc-800 border-zinc-700"
            value={localProfile.bio}
            onChange={(e) => handleChange("bio", e.target.value)}
          />
        </div>

        <div className="flex items-center space-x-4 mt-2">
          <button
            onClick={() => setLocationToggle(!locationToggle)}
            className={`p-2 rounded-md transition-colors ${
              locationToggle
                ? "bg-zinc-700 text-white"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <MapPin className="w-5 h-5" />
          </button>
          <button
            onClick={() => setRateToggle(!rateToggle)}
            className={`p-2 rounded-md transition-colors ${
              rateToggle
                ? "bg-zinc-700 text-white"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <Banknote className="w-5 h-5" />
          </button>
          <button
            onClick={() => setMailToggle(!mailToggle)}
            className={`p-2 rounded-md transition-colors ${
              mailToggle
                ? "bg-zinc-700 text-white"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <Mail className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 mt-2">
          {locationToggle && (
            <div className="flex items-center space-x-2 animate-in fade-in slide-in-from-top-2">
              <MapPin className="w-5 h-5 text-zinc-400" />
              <Input
                placeholder="Enter your location"
                className="bg-zinc-800 border-zinc-700"
                value={localProfile.location}
                onChange={(e) => handleChange("location", e.target.value)}
              />
            </div>
          )}

          {rateToggle && (
            <div className="flex items-center space-x-2 animate-in fade-in slide-in-from-top-2">
              <Banknote className="w-5 h-5 text-zinc-400" />
              <Input
                placeholder="Enter Revenue(leave blank if null)."
                type="text"
                className="bg-zinc-800 border-zinc-700"
                value={localProfile.rate}
                onChange={(e) => handleChange("rate", e.target.value)}
              />
            </div>
          )}

          {mailToggle && (
            <div className="flex items-center space-x-2 animate-in fade-in slide-in-from-top-2">
              <Mail className="w-5 h-5 text-zinc-400" />
              <Input
                readOnly
                placeholder="Enter your email address"
                type="email"
                className="bg-zinc-800 border-zinc-700"
                value={localProfile.email}
                onChange={(e) => handleChange("email", e.target.value)}
              />
            </div>
          )}
        </div>

        <Button onClick={handleSave} disabled={!isDirty} className="">
          Save Changes
        </Button>
      </div>
      <hr className="my-10" />

      <Products />
    </div>
  );
};

export default Profile;
