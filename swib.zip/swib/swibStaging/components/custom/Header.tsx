"use client";
import {
  User,
  Pen,
  BarChart2,
  Settings,
  LayoutDashboard,
  Brush,
  Menu,
  Magnet,
  WandSparkles,
  Sparkles,
  CheckCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useProfile } from "../providers/profile-context";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Dashboard from "@/app/dashboard/page";

export default function Header() {
  const router = useRouter();
  const profile = useProfile();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleDeploy = () => {
    router.push("/dashboard/settings");
  };

  return (
    <header className="bg-zinc-900 rounded-xl mx-4 md:mx-10 my-4 md:my-10">
      <div className="px-4 py-3">
        {/* Mobile Menu Button */}
        <div className="flex md:hidden items-center justify-between mb-2">
          <Button
            variant="ghost"
            className="text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu className="w-6 h-6" />
          </Button>
          {/* Deploy Button for Mobile */}
          <div>
            {profile.profile.deploy_name ? (
              <Button
                disabled
                className="bg-green-500 text-white flex items-center gap-2"
              >
                DEPLOYED
                <CheckCheck className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                onClick={handleDeploy}
                className="bg-pink-500 hover:bg-pink-600 text-white flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Publish Now
              </Button>
            )}
          </div>
        </div>

        {/* Desktop and Mobile Navigation */}
        <div
          className={`${
            isMenuOpen ? "block md:flex" : "hidden md:flex"
          } md:items-center md:justify-between`}
        >
          <nav className="flex flex-col md:flex-row md:items-center md:space-x-4 space-y-2 md:space-y-0">
            <Button
              variant="ghost"
              className="text-white hover:bg-zinc-800 w-full md:w-auto justify-start md:justify-center"
              onClick={() => router.push("/dashboard")}
            >
              <LayoutDashboard className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
            <Button
              variant="ghost"
              className="text-white hover:bg-zinc-800 w-full md:w-auto justify-start md:justify-center"
              onClick={() => router.push("/dashboard/themes")}
            >
              <Brush className="w-4 h-4 mr-2" />
              Style
            </Button>
            <Button
              variant="ghost"
              className="text-white hover:bg-zinc-800 w-full md:w-auto justify-start md:justify-center"
              onClick={() => router.push("/dashboard/settings")}
            >
              <Settings className="w-4 h-4 mr-2" />
              SETTINGS
            </Button>
          </nav>

          {/* Deploy Button for Desktop */}
          <div className="hidden md:block">
            {profile.profile.deploy_name ? (
              <Button
                disabled
                className="bg-green-500 text-white flex items-center gap-2"
              >
                DEPLOYED
                <CheckCheck className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                onClick={handleDeploy}
                className="bg-pink-500 hover:bg-pink-600 text-white flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Publish Now
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
