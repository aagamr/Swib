"use client";
import React, { useState } from "react";
import { Share, ExternalLink, Clock, DollarSign } from "lucide-react";
import { useSession } from "next-auth/react";
import { useProfile } from "../providers/profile-context";
import { useProducts } from "../providers/product-context";
// import { themes } from "@/constants/constants";

type Theme = {
  name: string;
  borderColor: string;
  notchBg: string;
  mainBg: string;
  textColor: string;
  secondaryText: string;
  cardBg: string;
  accentBg: string;
};
export const themes: { [key: number]: Theme } = {
  0: {
    name: "Dark",
    borderColor: "border-zinc-700",
    notchBg: "bg-zinc-800",
    mainBg: "bg-zinc-900",
    textColor: "text-gray-300",
    secondaryText: "text-gray-400",
    cardBg: "bg-zinc-800",
    accentBg: "bg-indigo-600",
  },
  1: {
    name: "Nordic",
    borderColor: "border-slate-700",
    notchBg: "bg-slate-800",
    mainBg: "bg-slate-900",
    textColor: "text-slate-200",
    secondaryText: "text-slate-300",
    cardBg: "bg-slate-800",
    accentBg: "bg-blue-500",
  },
  2: {
    name: "Moonlight",
    borderColor: "border-indigo-900",
    notchBg: "bg-indigo-900",
    mainBg: "bg-indigo-950",
    textColor: "text-indigo-100",
    secondaryText: "text-indigo-200",
    cardBg: "bg-indigo-900",
    accentBg: "bg-violet-500",
  },
  3: {
    name: "Pastel Dream",
    borderColor: "border-purple-200",
    notchBg: "bg-purple-200",
    mainBg: "bg-purple-50",
    textColor: "text-purple-900",
    secondaryText: "text-purple-800",
    cardBg: "bg-purple-100",
    accentBg: "bg-violet-400",
  },
  4: {
    name: "Deep Ocean",
    borderColor: "border-blue-900",
    notchBg: "bg-blue-900",
    mainBg: "bg-blue-950",
    textColor: "text-blue-100",
    secondaryText: "text-blue-200",
    cardBg: "bg-blue-900",
    accentBg: "bg-cyan-500",
  },
  5: {
    name: "Soft Sky",
    borderColor: "border-sky-200",
    notchBg: "bg-sky-200",
    mainBg: "bg-sky-50",
    textColor: "text-sky-900",
    secondaryText: "text-sky-800",
    cardBg: "bg-sky-100",
    accentBg: "bg-blue-400",
  },
  6: {
    name: "Cosmic",
    borderColor: "border-violet-900",
    notchBg: "bg-violet-900",
    mainBg: "bg-violet-950",
    textColor: "text-violet-100",
    secondaryText: "text-violet-200",
    cardBg: "bg-violet-900",
    accentBg: "bg-purple-500",
  },
  7: {
    name: "Cotton Candy",
    borderColor: "border-pink-200",
    notchBg: "bg-pink-200",
    mainBg: "bg-pink-50",
    textColor: "text-pink-900",
    secondaryText: "text-pink-800",
    cardBg: "bg-pink-100",
    accentBg: "bg-fuchsia-400",
  },
  8: {
    name: "Midnight",
    borderColor: "border-slate-800",
    notchBg: "bg-slate-800",
    mainBg: "bg-slate-950",
    textColor: "text-slate-100",
    secondaryText: "text-slate-200",
    cardBg: "bg-slate-900",
    accentBg: "bg-indigo-500",
  },
  9: {
    name: "Lavender Mist",
    borderColor: "border-violet-200",
    notchBg: "bg-violet-200",
    mainBg: "bg-violet-50",
    textColor: "text-violet-900",
    secondaryText: "text-violet-800",
    cardBg: "bg-violet-100",
    accentBg: "bg-purple-400",
  },
  10: {
    name: "Deep Space",
    borderColor: "border-slate-800",
    notchBg: "bg-slate-900",
    mainBg: "bg-[#0A0C1B]",
    textColor: "text-slate-200",
    secondaryText: "text-slate-300",
    cardBg: "bg-slate-900",
    accentBg: "bg-indigo-800",
  },
  11: {
    name: "Shadow Realm",
    borderColor: "border-zinc-800",
    notchBg: "bg-zinc-900",
    mainBg: "bg-zinc-950",
    textColor: "text-zinc-200",
    secondaryText: "text-zinc-300",
    cardBg: "bg-zinc-900",
    accentBg: "bg-slate-700",
  },
  12: {
    name: "Dark Matter",
    borderColor: "border-gray-800",
    notchBg: "bg-gray-900",
    mainBg: "bg-[#080B14]",
    textColor: "text-gray-200",
    secondaryText: "text-gray-300",
    cardBg: "bg-gray-900",
    accentBg: "bg-blue-900",
  },
  13: {
    name: "Obsidian",
    borderColor: "border-neutral-800",
    notchBg: "bg-neutral-900",
    mainBg: "bg-[#070707]",
    textColor: "text-neutral-200",
    secondaryText: "text-neutral-300",
    cardBg: "bg-neutral-900",
    accentBg: "bg-neutral-800",
  },
  14: {
    name: "Void",
    borderColor: "border-violet-900",
    notchBg: "bg-violet-950",
    mainBg: "bg-[#0C061F]",
    textColor: "text-violet-200",
    secondaryText: "text-violet-300",
    cardBg: "bg-violet-950",
    accentBg: "bg-purple-900",
  },
  15: {
    name: "Dark Crystal",
    borderColor: "border-indigo-900",
    notchBg: "bg-indigo-950",
    mainBg: "bg-[#06081F]",
    textColor: "text-indigo-200",
    secondaryText: "text-indigo-300",
    cardBg: "bg-indigo-950",
    accentBg: "bg-violet-900",
  },
  16: {
    name: "Night Sky",
    borderColor: "border-blue-900",
    notchBg: "bg-blue-950",
    mainBg: "bg-[#030B1F]",
    textColor: "text-blue-200",
    secondaryText: "text-blue-300",
    cardBg: "bg-blue-950",
    accentBg: "bg-indigo-900",
  },
  17: {
    name: "Eclipse",
    borderColor: "border-slate-900",
    notchBg: "bg-[#0A0A14]",
    mainBg: "bg-black",
    textColor: "text-slate-200",
    secondaryText: "text-slate-300",
    cardBg: "bg-[#0A0A14]",
    accentBg: "bg-slate-800",
  },
};

const Preview = () => {
  const { data: session } = useSession();
  const profile = useProfile();
  const [themeIndex, setThemeIndex] = useState(profile.profile?.theme || 0);
  const currentTheme = themes[parseInt(profile.profile?.theme || "0")];

  const { products } = useProducts();

  // Theme switcher button for demonstration

  return (
    <>
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        {/* Theme switcher button */}

        <div
          className={`relative border-8 ${currentTheme.borderColor} rounded-[60px] overflow-hidden w-[380px] h-screen`}
        >
          <div
            className={`absolute top-0 left-1/2 transform -translate-x-1/2 w-[40%] h-[24px] ${currentTheme.notchBg} rounded-b-2xl`}
          />
          <div
            className={`${currentTheme.mainBg} ${currentTheme.textColor} h-screen overflow-y-auto`}
          >
            {/* Profile Section */}
            <div className="p-4 space-y-4 pt-10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-purple-600 overflow-hidden">
                    <img
                      src={profile.profile?.image || ""}
                      alt="Profile"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold">
                      {profile.profile.name || "Fetching..."}
                    </h2>
                    <p className={`text-sm ${currentTheme.secondaryText}`}>
                      📍 {profile.profile.location}
                    </p>
                  </div>
                </div>
                <div className={`${currentTheme.accentBg} p-2 rounded-lg`}>
                  <Share size={20} />
                </div>
              </div>

              <div>
                <div className={`text-sm ${currentTheme.secondaryText}`}>
                  {profile.profile.rate && (
                    <>💰 Revenue: {profile.profile.rate}</>
                  )}
                </div>
                <div className={`text-sm ${currentTheme.secondaryText}`}>
                  {profile.profile.email && (
                    <>✉️ Connect@: {profile.profile.email}</>
                  )}
                </div>
              </div>

              <div className="text-sm">{profile.profile.bio}</div>

              {/* Products Section */}
              <div className="space-y-4 mt-6">
                <h3 className="text-lg font-semibold">Projects</h3>
                {products.map((product) => (
                  <div
                    key={product._id}
                    className={`${currentTheme.cardBg} rounded-xl p-4 space-y-3`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg overflow-hidden">
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium">{product.name}</h4>
                          <div
                            className={`flex items-center gap-2 text-xs ${currentTheme.secondaryText}`}
                          >
                            <Clock size={12} />
                            <span>{product.duration}</span>
                          </div>
                        </div>
                      </div>
                      <a
                        href={product.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`${currentTheme.accentBg} p-2 rounded-lg`}
                      >
                        <ExternalLink size={16} />
                      </a>
                    </div>

                    <p className={`text-sm ${currentTheme.secondaryText}`}>
                      {product.description}
                    </p>

                    <div className="flex items-center justify-between text-sm">
                      <span
                        className={`px-2 py-1 rounded-full text-xs ${
                          product.status === "completed"
                            ? "bg-green-500/20 text-green-400"
                            : "bg-yellow-500/20 text-yellow-400"
                        }`}
                      >
                        {product.status.charAt(0).toUpperCase() +
                          product.status.slice(1)}
                      </span>

                      {product.revenue > 0 && (
                        <div className="flex items-center gap-1 text-green-400">
                          <DollarSign size={14} />
                          <span>{product.revenue}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                <div className="h-12"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Preview;
