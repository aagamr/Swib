"use client";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Plus, Upload } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ProductCard } from "../shared/ProductCard";
import { useSession } from "next-auth/react";
import axios from "axios";
import toast from "react-hot-toast";
import { Product } from "@/lib/types";
import { useProducts } from "../providers/product-context";

export const Products = () => {
  const { data: session } = useSession();
  const [products, setProducts] = useState<Product[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { getProducts } = useProducts();
  const [newProduct, setNewProduct] = useState({
    name: "",
    description: "",
    duration: "",
    status: "building" as const,
    revenue: 0,
    link: "",
  });

  const fetchProducts = async () => {
    try {
      const res = await axios.get(
        `/api/products?email=${session?.user?.email}`
      );
      setProducts(res.data);
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Failed to fetch products");
    }
  };

  useEffect(() => {
    if (session?.user?.email) {
      fetchProducts();
    }
  }, [session]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const formData = new FormData();
      Object.entries(newProduct).forEach(([key, value]) => {
        formData.append(key, value.toString());
      });
      if (selectedImage) {
        formData.append("image", selectedImage);
      }

      await axios.post(
        `/api/products?email=${session?.user?.email}`,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      toast.success("Product added successfully");
      setIsOpen(false);
      setNewProduct({
        name: "",
        description: "",
        duration: "",
        status: "building",
        revenue: 0,
        link: "",
      });
      setSelectedImage(null);
      setImagePreview(null);
      fetchProducts();
      getProducts();
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Failed to add product");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6">
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button className="w-full mb-6">
            <Plus className="mr-2" />
            Add
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Project</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Project Image</Label>
              <div className="flex flex-col items-center gap-4">
                {imagePreview ? (
                  <div className="relative w-32 h-32">
                    <img
                      src={imagePreview}
                      alt="Preview"
                      className="w-full h-full object-cover rounded-lg"
                    />
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      className="absolute bottom-2 right-2"
                      onClick={() => {
                        setSelectedImage(null);
                        setImagePreview(null);
                      }}
                      disabled={isLoading}
                    >
                      Remove
                    </Button>
                  </div>
                ) : (
                  <div className="w-32 h-32 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center">
                    <label className="cursor-pointer flex flex-col items-center">
                      <Upload className="w-8 h-8 text-gray-400" />
                      <span className="text-sm text-gray-500">
                        Upload Image
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageChange}
                        disabled={isLoading}
                      />
                    </label>
                  </div>
                )}
              </div>
            </div>
            <div>
              <Label>Name</Label>
              <Input
                value={newProduct.name}
                onChange={(e) =>
                  setNewProduct({ ...newProduct, name: e.target.value })
                }
                required
                disabled={isLoading}
              />
            </div>
            <div>
              <Label>Description</Label>
              <Input
                value={newProduct.description}
                onChange={(e) =>
                  setNewProduct({
                    ...newProduct,
                    description: e.target.value,
                  })
                }
                required
                disabled={isLoading}
              />
            </div>
            <div>
              <Label>Duration</Label>
              <Input
                value={newProduct.duration}
                onChange={(e) =>
                  setNewProduct({ ...newProduct, duration: e.target.value })
                }
                required
                disabled={isLoading}
              />
            </div>
            <div>
              <Label>Status</Label>
              <Select
                value={newProduct.status}
                onValueChange={(value: any) =>
                  setNewProduct({ ...newProduct, status: value })
                }
                disabled={isLoading}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="building">Building</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="onHold">On Hold</SelectItem>
                  <SelectItem value="discontinued">Discontinued</SelectItem>
                  <SelectItem value="working">Working</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Link</Label>
              <Input
                value={newProduct.link}
                onChange={(e) =>
                  setNewProduct({ ...newProduct, link: e.target.value })
                }
                disabled={isLoading}
              />
            </div>
            <Button type="submit" className="w-full" disabled={isLoading}>
              Add Project
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <div className="grid gap-6">
        {products.map((product) => (
          <ProductCard
            key={product._id}
            product={product}
            onSuccess={fetchProducts}
          />
        ))}
      </div>
    </div>
  );
};

export default Products;
