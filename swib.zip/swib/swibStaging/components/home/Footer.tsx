import Link from "next/link";

export const Footer1 = () => {
  const navigationItems = [
    {
      title: "Home",
      href: "/",
    },
    {
      title: "About Us",
      href: "/about",
    },
    {
      title: "Contact",
      href: "/contact",
    },
  ];

  return (
    <div className="w-full py-20 lg:py-20 bg-zinc-950 border-t border-zinc-800 text-zinc-100 px-10 md:px-40">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between gap-10 items-start md:items-center">
          <div className="flex gap-8 flex-col items-start">
            <div className="flex gap-2 flex-col">
              <h2 className="text-3xl md:text-5xl tracking-tighter max-w-xl font-regular text-left text-zinc-100">
                SWIB™
              </h2>
              <p className="text-lg max-w-lg leading-relaxed tracking-tight text-zinc-400 text-left">
                Showcase your journey with SWIB and connect with like-minded
                individuals.
              </p>
            </div>
            <div className="flex gap-20 flex-row">
              <div className="flex flex-col text-sm max-w-lg leading-relaxed tracking-tight text-zinc-400 text-left">
                <p>Connect with Us:</p>
                <Link
                  href="mailto:support@swib.com"
                  className="text-zinc-400 hover:text-zinc-100 transition-colors"
                >
                  support@swib.com
                </Link>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-6 items-start">
            {navigationItems.map((item) => (
              <div
                key={item.title}
                className="flex text-base gap-1 flex-col items-start"
              >
                <Link
                  href={item.href}
                  className="flex justify-between items-center text-zinc-400 hover:text-zinc-100 transition-colors"
                >
                  <span className="text-xl">{item.title}</span>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer1;
