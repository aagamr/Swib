import { MoveRight, PhoneCall } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export const CTA2 = () => (
  <div className="w-full  bg-zinc-950 border-t border-zinc-800 px-10 md:px-40">
    <div className="container mx-auto">
      <div className="flex flex-col text-center py-14 gap-4 items-center">
        <div>
          <Badge>Get started</Badge>
        </div>
        <div className="flex flex-col gap-2">
          <h3 className="text-3xl md:text-5xl tracking-tighter max-w-xl font-regular">
            Share Your Journey with SWIB Today!
          </h3>
          <p className="text-lg leading-relaxed tracking-tight text-muted-foreground max-w-xl">
            Whether you're a creator, builder, or innovator, SWIB helps you
            showcase your milestones, products, and the stories behind your
            successes. Start sharing your journey today and connect with a
            community of like-minded individuals.
          </p>
        </div>
        <div className="flex flex-row gap-4">
          <Link href="/khair">
            <Button className="gap-4">
              Check Demo <MoveRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  </div>
);
