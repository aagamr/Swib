import { HandMetal, Heart, LogIn, MoveRight, PhoneCall } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LoginButton } from "../auth/login-button";
import Link from "next/link";

export const HeroSection = () => (
  <div className="w-full pb-10 md:py-20 px-10 md:px-40">
    <div className="container mx-auto">
      <div className="grid grid-cols-1 gap-8 items-center md:grid-cols-2">
        <div className="flex gap-4 flex-col">
          <div>
            <Badge variant="outline">We&apos;re live!</Badge>
          </div>
          <div className={"flex gap-4 "}>
            <a
              href="https://www.producthunt.com/posts/swib?embed=true&utm_source=badge-top-post-badge&utm_medium=badge&utm_souce=badge-swib"
              target="_blank"
            >
              <img
                src="https://api.producthunt.com/widgets/embed-image/v1/top-post-badge.svg?post_id=743414&theme=light&period=daily"
                alt="SWIB - See&#0032;what&#0032;I&#0032;built | Product Hunt"
                // style="width: 250px; height: 54px;"
                width="200"
                height="54"
              />
            </a>

            <a
              href="https://www.producthunt.com/posts/swib?embed=true&utm_source=badge-top-post-topic-badge&utm_medium=badge&utm_souce=badge-swib"
              target="_blank"
            >
              <img
                src="https://api.producthunt.com/widgets/embed-image/v1/top-post-topic-badge.svg?post_id=743414&theme=light&period=monthly&topic_id=93"
                alt="SWIB - See&#0032;what&#0032;I&#0032;built | Product Hunt"
                width="200"
                height="54"
              />
            </a>
          </div>
          <div className="flex gap-4 flex-col">
            <h1 className="text-5xl md:text-7xl max-w-lg tracking-tighter text-left font-regular">
              See What I Built!
            </h1>
            <p className="text-xl leading-relaxed tracking-tight text-muted-foreground max-w-md text-left">
              &#34;Showcase your journey, share your success. Discover inspiring
              stories of innovation and impact on SWIB – where builders connect
              and grow&#34;
            </p>
          </div>
          <div className="flex flex-col md:flex-row gap-4 w-full">
            <Link href={"/khair"}>
              <Button size="lg" className="gap-4 w-full" variant="outline">
                Check Demo <Heart className="w-4 h-4" />
              </Button>
            </Link>
            <LoginButton>
              <Button size="lg" className="gap-4 w-full">
                <LogIn className="w-4 h-4" />
                Dashboard
              </Button>
            </LoginButton>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-8">
          {/* <div className="bg-muted rounded-md aspect-square">
            <img
              src="/images/4.png"
              alt="feature"
              className="w-full h-full object-cover object-top"
            />
          </div> */}
          <div className="rounded-md row-span-2">
            <img
              src="/images/6.png"
              alt="feature"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="bg-muted rounded-md row-span-2">
            <img
              src="/images/2.png"
              alt="feature"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
);
