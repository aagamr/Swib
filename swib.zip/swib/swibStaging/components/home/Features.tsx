import { Badge } from "@/components/ui/badge";

export const Features = () => (
  <div className="w-full px-10 md:px-40">
    <div className="container mx-auto">
      <div className="flex flex-col-reverse lg:flex-row gap-10 lg:items-center">
        <div className=" rounded-md w-full aspect-video h-full flex-1 border">
          <img
            src="/images/feature.png"
            alt="Hero"
            className="w-full h-full object-contain"
          />
        </div>
        <div className="flex gap-4 pl-0 lg:pl-20 flex-col  flex-1">
          <div>
            <Badge>Platform</Badge>
          </div>
          <div className="flex gap-2 flex-col">
            <h2 className="text-xl md:text-3xl md:text-5xl tracking-tighter lg:max-w-xl font-regular text-left">
              This is the Start of Your Next Big Chapter
            </h2>
            <p className="text-lg max-w-xl lg:max-w-sm leading-relaxed tracking-tight text-muted-foreground text-left">
              "Everyone has a story worth telling, and now, you have a platform
              to share it. Whether it's the products you've built, the
              milestones you've achieved, or the networks you've created, SWIB
              makes it easier than ever to showcase your journey and connect
              with like-minded innovators. Embrace a simpler, smarter way to
              highlight your work."
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
);
