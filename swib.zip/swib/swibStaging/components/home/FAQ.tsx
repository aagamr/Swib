import { Check, PhoneCall } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";

export const FAQ = () => (
  <div className="w-full py-20 lg:py-40  px-10 md:px-40">
    <div className="container mx-auto">
      <div className="grid lg:grid-cols-2 gap-10">
        <div className="flex gap-10 flex-col">
          <div className="flex gap-4 flex-col">
            <div>
              <Badge variant="outline">FAQ</Badge>
            </div>
            <div className="flex gap-2 flex-col">
              <h4 className="text-3xl md:text-5xl tracking-tighter max-w-xl text-left font-regular">
                Have Questions? We’ve Got Answers!
              </h4>
              <p className="text-lg max-w-xl lg:max-w-lg leading-relaxed tracking-tight text-muted-foreground  text-left">
                Whether you're new to SWIB or a seasoned user, we're here to
                help you get the most out of your journey-sharing experience.
                Explore our FAQs to find answers to common questions or reach
                out for further assistance.
              </p>
            </div>
          </div>
        </div>
        <Accordion type="single" collapsible className="w-full">
          {[
            "What is SWIB?",
            "How do I add my journey?",
            "What are the benefits of sharing my story?",
            "Is there a fee for using SWIB?",
            "Can I edit my journey after posting?",
            "How do I connect with others on SWIB?",
            "What type of content can I share?",
            "Can I share my journey anonymously?",
          ].map((question, index) => (
            <AccordionItem key={index} value={"index-" + index}>
              <AccordionTrigger>{question}</AccordionTrigger>
              <AccordionContent>
                {index === 0
                  ? "SWIB is a platform that allows builders, creators, and innovators to share their journeys, products, and milestones."
                  : index === 1
                  ? "Simply sign up, fill in your details, and share the products, companies, and milestones you've achieved."
                  : index === 2
                  ? "Sharing your story can inspire others, connect you with like-minded people, and help grow your network."
                  : index === 3
                  ? "No! SWIB is completely free to use."
                  : index === 4
                  ? "Yes, you can update your journey at any time through your profile."
                  : index === 5
                  ? "You can connect with others through the platform’s social and messaging features."
                  : index === 6
                  ? "You can share products, revenue milestones, and career highlights."
                  : "SWIB encourages transparency, but we respect your privacy. You can control the visibility of your posts."}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  </div>
);
