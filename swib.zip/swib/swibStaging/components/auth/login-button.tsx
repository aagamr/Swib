"use client";

import { signIn } from "next-auth/react";

interface LoginButtonProps {
  children: React.ReactNode;
}

export function LoginButton({ children }: LoginButtonProps) {
  const onClick = () => {
    signIn("google", { callbackUrl: "/dashboard" });
  };

  return (
    <span onClick={onClick} className="cursor-pointer">
      {children}
    </span>
  );
}
