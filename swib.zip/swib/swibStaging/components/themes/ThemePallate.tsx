import React from "react";
import { Theme } from "@/lib/types";
import { useProfile } from "../providers/profile-context";
import toast from "react-hot-toast";
import { Button } from "../ui/button";
// import { themes } from "@/constants/constants";
export const themes: { [key: number]: Theme } = {
  0: {
    name: "Dark",
    borderColor: "border-zinc-700",
    notchBg: "bg-zinc-800",
    mainBg: "bg-zinc-900",
    textColor: "text-gray-300",
    secondaryText: "text-gray-400",
    cardBg: "bg-zinc-800",
    accentBg: "bg-indigo-600",
  },
  1: {
    name: "Nordic",
    borderColor: "border-slate-700",
    notchBg: "bg-slate-800",
    mainBg: "bg-slate-900",
    textColor: "text-slate-200",
    secondaryText: "text-slate-300",
    cardBg: "bg-slate-800",
    accentBg: "bg-blue-500",
  },
  2: {
    name: "Moonlight",
    borderColor: "border-indigo-900",
    notchBg: "bg-indigo-900",
    mainBg: "bg-indigo-950",
    textColor: "text-indigo-100",
    secondaryText: "text-indigo-200",
    cardBg: "bg-indigo-900",
    accentBg: "bg-violet-500",
  },
  3: {
    name: "Pastel Dream",
    borderColor: "border-purple-200",
    notchBg: "bg-purple-200",
    mainBg: "bg-purple-50",
    textColor: "text-purple-900",
    secondaryText: "text-purple-800",
    cardBg: "bg-purple-100",
    accentBg: "bg-violet-400",
  },
  4: {
    name: "Deep Ocean",
    borderColor: "border-blue-900",
    notchBg: "bg-blue-900",
    mainBg: "bg-blue-950",
    textColor: "text-blue-100",
    secondaryText: "text-blue-200",
    cardBg: "bg-blue-900",
    accentBg: "bg-cyan-500",
  },
  5: {
    name: "Soft Sky",
    borderColor: "border-sky-200",
    notchBg: "bg-sky-200",
    mainBg: "bg-sky-50",
    textColor: "text-sky-900",
    secondaryText: "text-sky-800",
    cardBg: "bg-sky-100",
    accentBg: "bg-blue-400",
  },
  6: {
    name: "Cosmic",
    borderColor: "border-violet-900",
    notchBg: "bg-violet-900",
    mainBg: "bg-violet-950",
    textColor: "text-violet-100",
    secondaryText: "text-violet-200",
    cardBg: "bg-violet-900",
    accentBg: "bg-purple-500",
  },
  7: {
    name: "Cotton Candy",
    borderColor: "border-pink-200",
    notchBg: "bg-pink-200",
    mainBg: "bg-pink-50",
    textColor: "text-pink-900",
    secondaryText: "text-pink-800",
    cardBg: "bg-pink-100",
    accentBg: "bg-fuchsia-400",
  },
  8: {
    name: "Midnight",
    borderColor: "border-slate-800",
    notchBg: "bg-slate-800",
    mainBg: "bg-slate-950",
    textColor: "text-slate-100",
    secondaryText: "text-slate-200",
    cardBg: "bg-slate-900",
    accentBg: "bg-indigo-500",
  },
  9: {
    name: "Lavender Mist",
    borderColor: "border-violet-200",
    notchBg: "bg-violet-200",
    mainBg: "bg-violet-50",
    textColor: "text-violet-900",
    secondaryText: "text-violet-800",
    cardBg: "bg-violet-100",
    accentBg: "bg-purple-400",
  },
  10: {
    name: "Deep Space",
    borderColor: "border-slate-800",
    notchBg: "bg-slate-900",
    mainBg: "bg-[#0A0C1B]",
    textColor: "text-slate-200",
    secondaryText: "text-slate-300",
    cardBg: "bg-slate-900",
    accentBg: "bg-indigo-800",
  },
  11: {
    name: "Shadow Realm",
    borderColor: "border-zinc-800",
    notchBg: "bg-zinc-900",
    mainBg: "bg-zinc-950",
    textColor: "text-zinc-200",
    secondaryText: "text-zinc-300",
    cardBg: "bg-zinc-900",
    accentBg: "bg-slate-700",
  },
  12: {
    name: "Dark Matter",
    borderColor: "border-gray-800",
    notchBg: "bg-gray-900",
    mainBg: "bg-[#080B14]",
    textColor: "text-gray-200",
    secondaryText: "text-gray-300",
    cardBg: "bg-gray-900",
    accentBg: "bg-blue-900",
  },
  13: {
    name: "Obsidian",
    borderColor: "border-neutral-800",
    notchBg: "bg-neutral-900",
    mainBg: "bg-[#070707]",
    textColor: "text-neutral-200",
    secondaryText: "text-neutral-300",
    cardBg: "bg-neutral-900",
    accentBg: "bg-neutral-800",
  },
  14: {
    name: "Void",
    borderColor: "border-violet-900",
    notchBg: "bg-violet-950",
    mainBg: "bg-[#0C061F]",
    textColor: "text-violet-200",
    secondaryText: "text-violet-300",
    cardBg: "bg-violet-950",
    accentBg: "bg-purple-900",
  },
  15: {
    name: "Dark Crystal",
    borderColor: "border-indigo-900",
    notchBg: "bg-indigo-950",
    mainBg: "bg-[#06081F]",
    textColor: "text-indigo-200",
    secondaryText: "text-indigo-300",
    cardBg: "bg-indigo-950",
    accentBg: "bg-violet-900",
  },
  16: {
    name: "Night Sky",
    borderColor: "border-blue-900",
    notchBg: "bg-blue-950",
    mainBg: "bg-[#030B1F]",
    textColor: "text-blue-200",
    secondaryText: "text-blue-300",
    cardBg: "bg-blue-950",
    accentBg: "bg-indigo-900",
  },
  17: {
    name: "Eclipse",
    borderColor: "border-slate-900",
    notchBg: "bg-[#0A0A14]",
    mainBg: "bg-black",
    textColor: "text-slate-200",
    secondaryText: "text-slate-300",
    cardBg: "bg-[#0A0A14]",
    accentBg: "bg-slate-800",
  },
};

const ThemePalette = () => {
  const { profile, updateProfile, fetchProfile } = useProfile();
  const currentTheme = parseInt(profile.theme || "0");

  const handleThemeChange = async (themeNumber: number) => {
    try {
      await updateProfile("theme", themeNumber.toString());
      toast.success("Theme updated successfully!");
      fetchProfile();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="p-4 sm:p-6 w-full max-w-3xl">
      <div className="flex justify-between mb-4 items-center">
        <h2 className="text-xl font-semibold ">Theme</h2>
        <Button
          onClick={() => {
            if (profile.theme == "0") {
              toast.success("Default theme already selected");
            } else {
              handleThemeChange(0);
            }
          }}
          variant="outline"
          className="mt-4"
        >
          Reset to default
        </Button>
      </div>

      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2 sm:gap-4">
        {Object.entries(themes).map(([key, theme]) => (
          <button
            key={key}
            onClick={() => handleThemeChange(Number(key))}
            className={`group relative aspect-square rounded-lg p-1 ${
              currentTheme === Number(key) ? "ring-2 ring-blue-500" : ""
            }`}
          >
            <div className="h-full w-full rounded overflow-hidden">
              <div className={`h-1/2 ${theme.mainBg}`}>
                <div className={`h-1/2 ${theme.notchBg}`} />
                <div className={`h-1/2 ${theme.cardBg}`} />
              </div>
              <div className={`h-1/2 ${theme.accentBg}`} />
            </div>

            <div className="absolute opacity-0 group-hover:opacity-100 touch-device:opacity-100 bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 text-xs text-white bg-gray-900 rounded transition-opacity whitespace-nowrap">
              {theme.name}
            </div>
          </button>
        ))}
      </div>

      <p className="mt-4 ">
        <span className="font-semibold">Note:</span> It takes 30 sec to update
        the theme on your page.
      </p>
    </div>
  );
};

export default ThemePalette;
