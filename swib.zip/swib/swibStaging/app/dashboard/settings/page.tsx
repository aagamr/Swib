"use client";

import { useProfile } from "@/components/providers/profile-context";
import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card } from "@/components/ui/card";
import {
  Edit2,
  Save,
  X,
  Link as LinkIcon,
  Copy,
  ExternalLink,
} from "lucide-react";
import { signOut } from "next-auth/react";
import { useRouter } from "next/navigation";

const Settings = () => {
  const profile = useProfile();
  const router = useRouter();
  const [deployName, setDeployName] = useState("");
  const [editedDeployName, setEditedDeployName] = useState(
    profile.profile.deploy_name || ""
  );
  const [isEditing, setIsEditing] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const logout = async () => {
    await signOut();
    router.push("/");
  };
  const handleDeploy = async (name = deployName) => {
    try {
      setIsLoading(true);
      setError("");

      const response = await fetch(
        `/api/deploy?email=${profile.profile.email}&deployName=${name}`,
        { method: "PUT" }
      );

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || "Failed to deploy");
        return;
      }

      window.location.reload();
    } catch (err) {
      setError("Failed to deploy. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const deployUrl = `http://www.swib.in/${profile.profile.deploy_name}`;
  const url = `swib.in/${profile.profile.deploy_name}`;

  return (
    <div className="min-h-screen bg-zinc-950">
      <div className="max-w-2xl mx-auto px-4 py-12">
        <Card className="bg-zinc-900 border-zinc-800 p-8 space-y-6 rounded-xl">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-zinc-100 flex items-center gap-2">
              <LinkIcon className="w-6 h-6 text-indigo-400" />
              Deploy Settings
            </h2>
          </div>

          {profile.profile.deploy_name ? (
            <div className="space-y-6">
              <div className="space-y-3">
                <p className="text-sm text-zinc-400">Your deployed link:</p>
                <div className="flex flex-col gap-4">
                  {isEditing ? (
                    <div className="flex-1">
                      <Input
                        value={editedDeployName}
                        onChange={(e) => setEditedDeployName(e.target.value)}
                        className="bg-zinc-800 border-zinc-700 text-zinc-100"
                      />
                    </div>
                  ) : (
                    <div className="flex items-center justify-between p-4 bg-zinc-800/50 rounded-xl border border-zinc-800">
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <p className="font-medium text-zinc-200 truncate">
                          {url}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-zinc-400 hover:text-zinc-100"
                          onClick={() => copyToClipboard(deployUrl)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-zinc-400 hover:text-zinc-100"
                          onClick={() => window.open(deployUrl, "_blank")}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                  <div className="flex gap-2">
                    {isEditing ? (
                      <>
                        <Button
                          size="sm"
                          className="bg-indigo-600 hover:bg-indigo-500 text-white"
                          onClick={() => {
                            handleDeploy(editedDeployName);
                            setIsEditing(false);
                          }}
                          disabled={isLoading}
                        >
                          <Save className="w-4 h-4 mr-2" />
                          Save Changes
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-zinc-700 text-zinc-300 hover:bg-zinc-800"
                          onClick={() => {
                            setEditedDeployName(
                              profile.profile.deploy_name || ""
                            );
                            setIsEditing(false);
                          }}
                        >
                          <X className="w-4 h-4 mr-2" />
                          Cancel
                        </Button>
                      </>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-zinc-700 text-zinc-300 hover:bg-zinc-800"
                        onClick={() => setIsEditing(true)}
                      >
                        <Edit2 className="w-4 h-4 mr-2" />
                        Edit Deploy Name
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="space-y-3">
                <p className="text-sm text-zinc-400">
                  Choose a unique deploy name:
                </p>
                <div className="flex gap-2">
                  <Input
                    value={deployName}
                    onChange={(e) => setDeployName(e.target.value)}
                    placeholder="enter-deploy-name"
                    className="bg-zinc-800 border-zinc-700 text-zinc-100"
                  />
                  <Button
                    onClick={() => handleDeploy()}
                    disabled={!deployName || isLoading}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white"
                  >
                    {isLoading ? "Deploying..." : "Deploy"}
                  </Button>
                </div>
              </div>
            </div>
          )}

          {error && (
            <Alert
              variant="destructive"
              className="bg-red-500/10 border-red-500/20 text-red-400"
            >
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {copied && (
            <Alert className="bg-green-500/10 border-green-500/20 text-green-400">
              <AlertDescription>URL copied to clipboard!</AlertDescription>
            </Alert>
          )}
        </Card>
        <Button variant="destructive" className="w-full mt-4 " onClick={logout}>
          Log Out
        </Button>
      </div>
    </div>
  );
};

export default Settings;
