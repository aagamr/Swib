"use client";
import Header from "@/components/custom/Header";
import Preview from "@/components/custom/Preview";
import Profile from "@/components/custom/Profile";
import { ProductProvider } from "@/components/providers/product-context";
import { ProfileProvider } from "@/components/providers/profile-context";
import ThemePallate from "@/components/themes/ThemePallate";
import React, { useEffect } from "react";

const Dashboard = () => {
  return (
    <>
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="flex flex-col md:grid md:grid-cols-5 gap-6">
          <div className="w-full md:col-span-3">
            <ThemePallate />
          </div>
          <div className="w-full md:col-span-2 sm:p-10">
            <Preview />
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
