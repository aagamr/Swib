import { ProfileProvider } from "@/components/providers/profile-context";
import { ProductProvider } from "@/components/providers/product-context";
import Header from "@/components/custom/Header";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`antialiased`}>
        <ProfileProvider>
          <ProductProvider>
            <Header />
            {children}
          </ProductProvider>
        </ProfileProvider>
      </body>
    </html>
  );
}
