import { LoginButton } from "@/components/auth/login-button";
import IntercomWidget from "@/components/chatbot/IntercomWidget";
import { CTA2 } from "@/components/home/CTA";
import { FAQ } from "@/components/home/FAQ";
import { Features } from "@/components/home/Features";
import { Footer1 } from "@/components/home/Footer";
import { HeroSection } from "@/components/home/HeroSection";
import { Navbar } from "@/components/home/Navbar";
import { Pricing } from "@/components/home/Pricing";
import { Button } from "@/components/ui/button";
import { LogIn } from "lucide-react";

export default function Home() {
  return (
    <div className="">
      <Navbar />
      <HeroSection />
      <Features />
      {/* <Pricing /> */}
      <FAQ />
      <CTA2 />
      <Footer1 />
     
    </div>
  );
}
