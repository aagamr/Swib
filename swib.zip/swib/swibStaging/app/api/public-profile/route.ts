import connectDb from "@/db/db";
import { User } from "@/models/userModel";
import { NextRequest, NextResponse } from "next/server";
import { Product } from "@/models/productsModel";
let isConnected = false;

export async function GET(request: NextRequest) {
  try {
    // Only try to connect if not already connected
    if (!isConnected) {
      try {
        await connectDb();
        isConnected = true;
      } catch (error) {
        console.error("Database connection failed:", error);
        return NextResponse.json(
          { message: "Database connection failed" },
          { status: 500 }
        );
      }
    }

    const url = request.nextUrl.searchParams.get("url");
    if (!url) {
      return NextResponse.json(
        { message: "URL parameter is required" },
        { status: 400 }
      );
    }
    const products = await Product.countDocuments({});
    const user = await User.findOne({ deploy_name: url }).populate("products");
    user.products.reverse();
    if (!user) {
      return NextResponse.json({ message: "User not found" }, { status: 404 });
    }

    // Add cache headers
    const response = NextResponse.json(user);
    response.headers.set(
      "Cache-Control",
      "s-maxage=60, stale-while-revalidate"
    );

    return response;
  } catch (error: any) {
    console.error("API error:", error);
    return NextResponse.json(
      { message: "Failed to fetch user", error: error.message },
      { status: 500 }
    );
  }
}
