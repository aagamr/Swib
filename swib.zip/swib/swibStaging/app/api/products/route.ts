import { v2 as cloudinary } from "cloudinary";
import { NextRequest, NextResponse } from "next/server";
import connectDb from "@/db/db";
import { Product } from "@/models/productsModel";
import { User } from "@/models/userModel";
import { getToken } from "next-auth/jwt";

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true,
});

// Helper function to handle errors
const handleError = (error: any) => {
  console.error("API Error:", error);
  return NextResponse.json(
    { error: "An error occurred", details: error.message },
    { status: error.status || 500 }
  );
};

// Helper function to upload image to Cloudinary
const uploadToCloudinary = async (imageFile: File): Promise<string> => {
  const fileBuffer = await imageFile.arrayBuffer();
  const mime = imageFile.type;
  const encoding = "base64";
  const base64Data = Buffer.from(fileBuffer).toString("base64");
  const fileUri = `data:${mime};${encoding},${base64Data}`;

  try {
    const result = await cloudinary.uploader.upload(fileUri, {
      invalidate: true,
    });
    return result.secure_url;
  } catch (error) {
    throw new Error("Cloudinary upload failed");
  }
};

// const deleteFromCloudinary = async (imageUrl: string) => {
//   try {
//     const publicId = imageUrl.split("/").pop()?.split(".")[0];
//     if (publicId) {
//       await cloudinary.uploader.destroy(products/${publicId});
//     }
//   } catch (error) {
//     console.error("Error deleting image from Cloudinary:", error);
//   }
// };

// POST: Create a new product
export async function POST(request: NextRequest) {
  try {
    await connectDb();

    const email = request.nextUrl.searchParams.get("email");
    if (!email) {
      return NextResponse.json({ error: "Email is required" }, { status: 400 });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const token = await getToken({ req: request });
    if (!token || token.email !== email) {
      return NextResponse.json({ error: "UnAuthorized" }, { status: 401 });
    }

    const formData = await request.formData();
    const name = formData.get("name") as string;
    const description = formData.get("description") as string;
    const duration = formData.get("duration") as string;
    const status = formData.get("status") as string;
    const revenue = Number(formData.get("revenue")) || 0;
    const link = formData.get("link") as string;
    const imageFile = formData.get("image") as File | null;

    if (!name || !description) {
      return NextResponse.json(
        { error: "Name and description are required" },
        { status: 400 }
      );
    }

    let imageUrl = "";
    if (imageFile) {
      if (!imageFile.type.startsWith("image/")) {
        return NextResponse.json(
          { error: "Invalid file type. Only images are allowed." },
          { status: 400 }
        );
      }
      if (imageFile.size > 5 * 1024 * 1024) {
        return NextResponse.json(
          { error: "File size too large. Maximum size is 5MB." },
          { status: 400 }
        );
      }
      imageUrl = await uploadToCloudinary(imageFile);
    }

    const highestRank = await Product.findOne().sort("-rank");
    const newRank = (highestRank?.rank || 0) + 1;

    const productData = {
      user: user._id,
      name,
      description,
      duration,
      status,
      revenue,
      link,
      image: imageUrl,
      rank: newRank,
    };

    const product = await Product.create(productData);

    await User.findByIdAndUpdate(
      user._id,
      { $push: { products: product._id } },
      { new: true }
    );

    return NextResponse.json(product, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

// PUT: Update a product
export async function PUT(request: NextRequest) {
  try {
    await connectDb();

    const email = request.nextUrl.searchParams.get("email");
    const productId = request.nextUrl.searchParams.get("productId");
    const token = await getToken({ req: request });
    if (!token) {
      return NextResponse.json({ error: "UnAuthorized" }, { status: 401 });
    }

    if (!token || token.email != email) {
      return NextResponse.json({ error: "UnAuthorized" }, { status: 401 });
    }
    if (!email || !productId) {
      return NextResponse.json(
        { error: "Email and Product ID are required" },
        { status: 400 }
      );
    }

    const user = await User.findOne({ email });
    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const existingProduct = await Product.findOne({
      _id: productId,
      user: user._id,
    });
    if (!existingProduct) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    const formData = await request.formData();
    const updateData: any = {};

    // Handle regular fields
    for (const [key, value] of formData.entries()) {
      if (key !== "image") {
        updateData[key] = value;
      }
    }

    // Handle image upload
    const imageFile = formData.get("image") as File | null;
    if (imageFile) {
      if (!imageFile.type.startsWith("image/")) {
        return NextResponse.json(
          { error: "Invalid file type. Only images are allowed." },
          { status: 400 }
        );
      }
      if (imageFile.size > 5 * 1024 * 1024) {
        return NextResponse.json(
          { error: "File size too large. Maximum size is 5MB." },
          { status: 400 }
        );
      }

      updateData.image = await uploadToCloudinary(imageFile);

      if (existingProduct.image) {
        const publicId = existingProduct.image.split("/").pop()?.split(".")[0];
        if (publicId) {
          await cloudinary.uploader.destroy(`products/${publicId}`);
        }
      }
    }

    const updatedProduct = await Product.findOneAndUpdate(
      { _id: productId, user: user._id },
      updateData,
      { new: true }
    );

    return NextResponse.json(updatedProduct);
  } catch (error) {
    return handleError(error);
  }
}

// DELETE: Remove a product
export async function DELETE(request: NextRequest) {
  try {
    await connectDb();

    const email = request.nextUrl.searchParams.get("email");
    const productId = request.nextUrl.searchParams.get("productId");
    const token = await getToken({ req: request });
    if (!token || token.email != email) {
      return NextResponse.json({ error: "UnAuthorized" }, { status: 401 });
    }
    if (!email || !productId) {
      return NextResponse.json(
        { error: "Email and Product ID are required" },
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    const user = await User.findOne({ email });
    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        {
          status: 404,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    const product = await Product.findOne({
      _id: productId,
      user: user._id,
    });

    if (!product) {
      return NextResponse.json(
        { error: "Product not found" },
        {
          status: 404,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    // if (product.image) {
    //   await deleteFromCloudinary(product.image);
    // }

    await Product.deleteOne({ _id: productId });

    // Remove product reference from user
    await User.findByIdAndUpdate(user._id, { $pull: { products: productId } });

    return NextResponse.json(
      { message: "Product deleted successfully" },
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    return handleError(error);
  }
}
// GET: Fetch all products for a user
export async function GET(request: NextRequest) {
  try {
    await connectDb();
    const email = request.nextUrl.searchParams.get("email");
    if (!email) {
      return NextResponse.json(
        { error: "Email is required" },
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    const user = await User.findOne({ email });
    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        {
          status: 404,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    const products = await Product.find({ user: user._id }).sort({
      createdAt: -1,
    });

    return NextResponse.json(products, {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error: any) {
    return handleError(error);
  }
}
