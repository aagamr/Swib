import { NextRequest, NextResponse } from "next/server";
import { User } from "@/models/userModel";
import connectDb from "@/db/db";
import { v2 as cloudinary } from "cloudinary";
import { getToken } from "next-auth/jwt";

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true,
});

// Helper function to upload image to Cloudinary
const uploadToCloudinary = async (imageFile: File): Promise<string> => {
  const fileBuffer = await imageFile.arrayBuffer();
  const mime = imageFile.type;
  const encoding = "base64";
  const base64Data = Buffer.from(fileBuffer).toString("base64");
  const fileUri = `data:${mime};${encoding},${base64Data}`;

  try {
    const result = await cloudinary.uploader.upload(fileUri, {
      folder: "profiles",
      invalidate: true,
    });
    return result.secure_url;
  } catch (error) {
    throw new Error("Cloudinary upload failed");
  }
};

export async function GET(request: NextRequest) {
  try {
    await connectDb();
    const email = request.nextUrl.searchParams.get("email");

    const user = await User.findOne({ email });
    return NextResponse.json(user);
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch user" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    await connectDb();
    const token = await getToken({ req: request });
    console.log("Token:", token);
    if (!token) {
      return NextResponse.json({ error: "UnAuthorized" }, { status: 401 });
    }
    // Check if the request is multipart/form-data
    const contentType = request.headers.get("content-type");
    let updateData: any = {};
    let email: string = "";

    if (contentType?.includes("multipart/form-data")) {
      const formData = await request.formData();
      email = formData.get("email") as string;
      if (token.email !== email) {
        return NextResponse.json({ error: "UnAuthorized" }, { status: 401 });
      }
      const imageFile = formData.get("image") as File | null;
      if (imageFile) {
        const imageUrl = await uploadToCloudinary(imageFile);
        updateData.image = imageUrl;
      }
    } else {
      const data = await request.json();
      email = data.email;
      const { email: _, ...rest } = data;
      updateData = rest;
    }

    if (!email) {
      return NextResponse.json({ error: "Email is required" }, { status: 400 });
    }

    // If there's an existing image and we're uploading a new one, we could delete the old one here
    if (updateData.image) {
      const existingUser = await User.findOne({ email });
      if (existingUser?.image) {
        const publicId = existingUser.image.split("/").pop()?.split(".")[0];
        if (publicId) {
          await cloudinary.uploader.destroy(`profiles/${publicId}`);
        }
      }
    }

    const user = await User.findOneAndUpdate({ email }, updateData, {
      new: true,
    });

    return NextResponse.json(user);
  } catch (error) {
    console.error("Update error:", error);
    return NextResponse.json(
      { error: "Failed to update user" },
      { status: 500 }
    );
  }
}
