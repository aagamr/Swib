import connectDb from "@/db/db";
import { User } from "@/models/userModel";
import { getToken } from "next-auth/jwt";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    await connectDb();
    const deployName = request.nextUrl.searchParams.get("deployName");

    // Check if deploy name exists
    const existingUser = await User.findOne({ deploy_name: deployName });

    if (existingUser) {
      return NextResponse.json(
        { error: "Deploy name already taken" },
        { status: 400 }
      );
    }

    return NextResponse.json({ available: true });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to check deploy name" },
      { status: 500 }
    );
  }
}
export async function PUT(request: NextRequest) {
  try {
    await connectDb();
    const email = request.nextUrl.searchParams.get("email");
    const deployName = request.nextUrl.searchParams.get("deployName");

    // Check if deploy name is already taken
    const token = await getToken({ req: request });
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    if (token.email !== email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const existingUser = await User.findOne({ deploy_name: deployName });
    if (existingUser) {
      return NextResponse.json(
        { error: "Deploy name already taken" },
        { status: 400 }
      );
    }

    // Update user with new deploy name
    const user = await User.findOneAndUpdate(
      { email },
      { deploy_name: deployName },
      { new: true }
    );

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    return NextResponse.json({ message: "Deployed" });
  } catch (error) {
    return NextResponse.json({ error: "Failed to deploy" }, { status: 500 });
  }
}
