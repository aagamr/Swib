import IntercomWidget from "@/components/chatbot/IntercomWidget";
import "./globals.css";
import { AuthProvider } from "@/components/providers/auth-provider";
import { ThemeProvider } from "@/components/theme-provider";

import type { Metadata } from "next";
import localFont from "next/font/local";
import { Toaster } from "react-hot-toast";

const googleSans = localFont({
  src: [
    {
      path: "./fonts/GoogleSans-Regular.ttf",
      weight: "400",
      style: "normal",
    },
    {
      path: "./fonts/GoogleSans-Medium.ttf",
      weight: "500",
      style: "normal",
    },
    {
      path: "./fonts/GoogleSans-Bold.ttf",
      weight: "700",
      style: "normal",
    },
    {
      path: "./fonts/GoogleSans-Italic.ttf",
      weight: "400",
      style: "italic",
    },
  ],
  variable: "--font-google-sans",
});

export const metadata: Metadata = {
  title: "SWIB",
  description: "Swib is a platform for sharing your journey.",
  icons: {
    icon: "/favicon.ico", // Assumes favicon.ico is in the app directory
    // You can also add multiple sizes if you have them
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${googleSans.variable} antialiased`}>
        <AuthProvider>
          <ThemeProvider
            attribute="class"
            defaultTheme="dark"
            enableSystem
            disableTransitionOnChange
          >
            <Toaster reverseOrder={false} />
            {children}
            <IntercomWidget />
          </ThemeProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
