import Header from "@/components/custom/Header";
import { Footer1 } from "@/components/home/Footer";
import { Navbar } from "@/components/home/Navbar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoveRight, Users, Building, Trophy, Github } from "lucide-react";
import Link from "next/link";

const AboutHero = () => (
  <div className="w-full py-20 px-10 md:px-40 ">
    <div className="container mx-auto">
      <div className="flex flex-col gap-6 items-center text-center">
        <Badge variant="outline">About Us</Badge>
        <h1 className="text-5xl md:text-7xl max-w-3xl tracking-tighter font-regular">
          Building the Future of Journey Sharing
        </h1>
        <p className="text-xl leading-relaxed tracking-tight text-muted-foreground max-w-2xl">
          At SWIB, we believe every builder, creator, and innovator has a unique
          story worth sharing. Our platform connects passionate individuals who
          are shaping the future through their work.
        </p>
      </div>
    </div>
  </div>
);

const Stats = () => (
  <div className="w-full py-16 bg-zinc-950">
    <div className="container mx-auto px-10 md:px-40">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { icon: Users, label: "Active Users", value: "40+" },
          { icon: Building, label: "Projects Shared", value: "25+" },
          { icon: Trophy, label: "Success Stories", value: "10+" },
        ].map((stat, index) => (
          <div
            key={index}
            className="flex flex-col items-center gap-4 p-6 text-center"
          >
            <stat.icon className="w-8 h-8 text-primary" />
            <h3 className="text-4xl font-bold">{stat.value}</h3>
            <p className="text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const Team = () => (
  <div className="w-full py-20 px-10 md:px-40 ">
    <div className="container mx-auto">
      <div className="flex flex-col gap-10 items-center text-center">
        <div className="flex flex-col gap-4 items-center">
          <Badge className="w-20">Our Team</Badge>
          <h2 className="text-3xl md:text-5xl tracking-tighter max-w-xl font-regular">
            Meet the Builder Behind SWIB
          </h2>
          <p className="text-lg leading-relaxed tracking-tight text-muted-foreground max-w-2xl">
            We're a passionate team of builders, designers, and community
            advocates working together to create the best platform for sharing
            builder journeys.
          </p>
        </div>
        <div className="">
          <div className="flex flex-col items-center gap-4">
            <div className="w-32 h-32 rounded-full bg-muted">
              <img
                src="https://avatars.githubusercontent.com/u/130190342?s=400&u=c8e7c90311c257568145d7adc3f94a65fa4c0597&v=4"
                alt=""
                className="w-full h-full object-cover rounded-full"
              />
            </div>
            <h3 className="text-xl font-semibold">Yogesh Vashisth</h3>

            <Button>
              <a href="https://github.com/yogeshvas">
                <Github className="w-6 h-6" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const AboutPage = () => (
  <div className="flex flex-col min-h-screen">
    <Navbar />
    <AboutHero />
    <Stats />

    <Team />
    <Footer1 />
  </div>
);

export default AboutPage;
