"use client";

import React, { useEffect, useState } from "react";
import { Share, ExternalLink, Clock, DollarSign, Sparkles } from "lucide-react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";

interface Product {
  _id: string;
  user: string;
  rank: number;
  name: string;
  image: string;
  description: string;
  link: string;
  duration: string;
  status: "completed" | "building";
  revenue: number;
  createdAt: string;
}

interface Profile {
  _id: string;
  email: string;
  name: string;
  image: string;
  products: Product[];
  location: string;
  rate: string;
  bio: string;
  createdAt: string;
  deploy_name: string;
  theme: string;
}
interface Theme {
  name: string;
  borderColor: string;
  notchBg: string;
  mainBg: string;
  textColor: string;
  secondaryText: string;
  cardBg: string;
  accentBg: string;
}

const themes: { [key: number]: Theme } = {
  0: {
    name: "Dark",
    borderColor: "border-zinc-700",
    notchBg: "bg-zinc-800",
    mainBg: "bg-zinc-900",
    textColor: "text-gray-300",
    secondaryText: "text-gray-400",
    cardBg: "bg-zinc-800",
    accentBg: "bg-indigo-600",
  },
  1: {
    name: "Nordic",
    borderColor: "border-slate-700",
    notchBg: "bg-slate-800",
    mainBg: "bg-slate-900",
    textColor: "text-slate-200",
    secondaryText: "text-slate-300",
    cardBg: "bg-slate-800",
    accentBg: "bg-blue-500",
  },
  2: {
    name: "Moonlight",
    borderColor: "border-indigo-900",
    notchBg: "bg-indigo-900",
    mainBg: "bg-indigo-950",
    textColor: "text-indigo-100",
    secondaryText: "text-indigo-200",
    cardBg: "bg-indigo-900",
    accentBg: "bg-violet-500",
  },
  3: {
    name: "Pastel Dream",
    borderColor: "border-purple-200",
    notchBg: "bg-purple-200",
    mainBg: "bg-purple-50",
    textColor: "text-purple-900",
    secondaryText: "text-purple-800",
    cardBg: "bg-purple-100",
    accentBg: "bg-violet-400",
  },
  4: {
    name: "Deep Ocean",
    borderColor: "border-blue-900",
    notchBg: "bg-blue-900",
    mainBg: "bg-blue-950",
    textColor: "text-blue-100",
    secondaryText: "text-blue-200",
    cardBg: "bg-blue-900",
    accentBg: "bg-cyan-500",
  },
  5: {
    name: "Soft Sky",
    borderColor: "border-sky-200",
    notchBg: "bg-sky-200",
    mainBg: "bg-sky-50",
    textColor: "text-sky-900",
    secondaryText: "text-sky-800",
    cardBg: "bg-sky-100",
    accentBg: "bg-blue-400",
  },
  6: {
    name: "Cosmic",
    borderColor: "border-violet-900",
    notchBg: "bg-violet-900",
    mainBg: "bg-violet-950",
    textColor: "text-violet-100",
    secondaryText: "text-violet-200",
    cardBg: "bg-violet-900",
    accentBg: "bg-purple-500",
  },
  7: {
    name: "Cotton Candy",
    borderColor: "border-pink-200",
    notchBg: "bg-pink-200",
    mainBg: "bg-pink-50",
    textColor: "text-pink-900",
    secondaryText: "text-pink-800",
    cardBg: "bg-pink-100",
    accentBg: "bg-fuchsia-400",
  },
  8: {
    name: "Midnight",
    borderColor: "border-slate-800",
    notchBg: "bg-slate-800",
    mainBg: "bg-slate-950",
    textColor: "text-slate-100",
    secondaryText: "text-slate-200",
    cardBg: "bg-slate-900",
    accentBg: "bg-indigo-500",
  },
  9: {
    name: "Lavender Mist",
    borderColor: "border-violet-200",
    notchBg: "bg-violet-200",
    mainBg: "bg-violet-50",
    textColor: "text-violet-900",
    secondaryText: "text-violet-800",
    cardBg: "bg-violet-100",
    accentBg: "bg-purple-400",
  },
  10: {
    name: "Deep Space",
    borderColor: "border-slate-800",
    notchBg: "bg-slate-900",
    mainBg: "bg-[#0A0C1B]",
    textColor: "text-slate-200",
    secondaryText: "text-slate-300",
    cardBg: "bg-slate-900",
    accentBg: "bg-indigo-800",
  },
  11: {
    name: "Shadow Realm",
    borderColor: "border-zinc-800",
    notchBg: "bg-zinc-900",
    mainBg: "bg-zinc-950",
    textColor: "text-zinc-200",
    secondaryText: "text-zinc-300",
    cardBg: "bg-zinc-900",
    accentBg: "bg-slate-700",
  },
  12: {
    name: "Dark Matter",
    borderColor: "border-gray-800",
    notchBg: "bg-gray-900",
    mainBg: "bg-[#080B14]",
    textColor: "text-gray-200",
    secondaryText: "text-gray-300",
    cardBg: "bg-gray-900",
    accentBg: "bg-blue-900",
  },
  13: {
    name: "Obsidian",
    borderColor: "border-neutral-800",
    notchBg: "bg-neutral-900",
    mainBg: "bg-[#070707]",
    textColor: "text-neutral-200",
    secondaryText: "text-neutral-300",
    cardBg: "bg-neutral-900",
    accentBg: "bg-neutral-800",
  },
  14: {
    name: "Void",
    borderColor: "border-violet-900",
    notchBg: "bg-violet-950",
    mainBg: "bg-[#0C061F]",
    textColor: "text-violet-200",
    secondaryText: "text-violet-300",
    cardBg: "bg-violet-950",
    accentBg: "bg-purple-900",
  },
  15: {
    name: "Dark Crystal",
    borderColor: "border-indigo-900",
    notchBg: "bg-indigo-950",
    mainBg: "bg-[#06081F]",
    textColor: "text-indigo-200",
    secondaryText: "text-indigo-300",
    cardBg: "bg-indigo-950",
    accentBg: "bg-violet-900",
  },
  16: {
    name: "Night Sky",
    borderColor: "border-blue-900",
    notchBg: "bg-blue-950",
    mainBg: "bg-[#030B1F]",
    textColor: "text-blue-200",
    secondaryText: "text-blue-300",
    cardBg: "bg-blue-950",
    accentBg: "bg-indigo-900",
  },
  17: {
    name: "Eclipse",
    borderColor: "border-slate-900",
    notchBg: "bg-[#0A0A14]",
    mainBg: "bg-black",
    textColor: "text-slate-200",
    secondaryText: "text-slate-300",
    cardBg: "bg-[#0A0A14]",
    accentBg: "bg-slate-800",
  },
};

const Public = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(false);
  const { id } = useParams();
  const router = useRouter();

  const currentTheme = profile?.theme
    ? themes[parseInt(profile.theme)]
    : themes[0];

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        setIsLoading(true);
        setError(false);
        const response = await fetch(`/api/public-profile?url=${id}`);
        if (!response.ok) {
          setError(true);
          return;
        }
        const data = await response.json();
        setProfile(data);
      } catch (error) {
        setError(true);
      } finally {
        setIsLoading(false);
      }
    };

    if (id) {
      fetchProfile();
    }
  }, [id]);

  if (isLoading) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center ${currentTheme.mainBg}`}
      >
        <div className={currentTheme.secondaryText}>Loading...</div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div
        className={`min-h-screen ${currentTheme.mainBg} flex items-center justify-center px-4`}
      >
        <div className="max-w-md w-full">
          <div
            className={`${currentTheme.cardBg} rounded-3xl p-8 ${currentTheme.borderColor} text-center mb-8`}
          >
            <div
              className={`w-20 h-20 ${currentTheme.notchBg} rounded-full mx-auto mb-6 flex items-center justify-center`}
            >
              <span className="text-3xl">🔍</span>
            </div>
            <h1 className={`text-2xl font-bold ${currentTheme.textColor} mb-3`}>
              Profile Not Found
            </h1>
            <p className={currentTheme.secondaryText}>
              We couldn't find the profile you're looking for. It might have
              been removed or the URL could be incorrect.
            </p>
          </div>

          <div className="bg-gradient-to-r from-indigo-500 to-purple-500 rounded-2xl p-1">
            <div
              className={`${currentTheme.cardBg} rounded-xl p-6 flex flex-col items-center gap-4`}
            >
              <div className="h-12 w-12 bg-indigo-500/10 rounded-xl flex items-center justify-center mb-2">
                <Sparkles className="w-6 h-6 text-indigo-400" />
              </div>
              <div className="text-center">
                <h3
                  className={`text-lg font-semibold ${currentTheme.textColor}`}
                >
                  Create Your Own Profile
                </h3>
                <p className={`${currentTheme.secondaryText} text-sm mb-6`}>
                  Join thousands of entrepreneurs showcasing their journey
                </p>
              </div>
              <Link
                href="/"
                className={`w-full ${currentTheme.accentBg} text-white px-6 py-3 rounded-xl font-medium hover:opacity-90 transition shadow-lg text-center`}
              >
                Build Your Page
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${currentTheme.mainBg} px-7`}>
      {/* Profile Header - Mobile */}
      <div className="md:hidden pt-10 pb-4">
        <div className="flex items-center gap-4">
          <img
            src={profile.image}
            alt={profile.name}
            className="w-16 h-16 rounded-full object-cover ring-2 ring-indigo-500/20"
          />
          <div>
            <h1 className={`text-xl font-bold ${currentTheme.textColor}`}>
              {profile.name}
            </h1>
            <p className={currentTheme.secondaryText}>📍 {profile.location}</p>
          </div>
          <button
            className={`ml-auto ${currentTheme.accentBg} text-white p-2 rounded-lg`}
          >
            <Share className="w-5 h-5" />
          </button>
        </div>

        <p className={`text-sm ${currentTheme.textColor} mt-4`}>
          {profile.bio}
        </p>
        <div className="flex flex-col items-center gap-4 mt-4">
          {profile.rate && (
            <div
              className={`w-full flex-1 px-4 py-2 ${currentTheme.cardBg} rounded-xl ${currentTheme.borderColor}`}
            >
              <span className={currentTheme.secondaryText}>💰 Revenue</span>
              <p className={currentTheme.textColor}>{profile.rate}</p>
            </div>
          )}
          <div
            className={`w-full flex-1 px-4 py-2 ${currentTheme.cardBg} rounded-xl  ${currentTheme.borderColor}`}
          >
            <span className={currentTheme.secondaryText}>✉️ Email</span>
            <p className={`${currentTheme.textColor} truncate`}>
              {profile.email}
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto py-6 md:py-12">
        {/* Desktop Layout */}
        <div className="hidden md:flex flex-col md:flex-row md:items-start gap-6 md:gap-8 mb-8 md:mb-12">
          {/* Profile Info */}
          <div className="w-full md:w-1/3">
            <div
              className={`${currentTheme.cardBg} rounded-3xl p-6 md:p-8 ${currentTheme.borderColor}`}
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden mb-4 ring-2 ring-indigo-500/20">
                  <img
                    src={profile.image}
                    alt={profile.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h1
                  className={`text-xl md:text-2xl font-bold ${currentTheme.textColor} mb-2`}
                >
                  {profile.name}
                </h1>
                <p className={`${currentTheme.secondaryText} mb-4`}>
                  📍 {profile.location}
                </p>
                <p
                  className={`text-sm md:text-base ${currentTheme.textColor} mb-6`}
                >
                  {profile.bio}
                </p>

                <div className="w-full space-y-3">
                  {profile.rate && (
                    <div
                      className={`flex items-center justify-between px-4 py-2 ${currentTheme.notchBg} rounded-xl border ${currentTheme.borderColor}`}
                    >
                      <span className={currentTheme.secondaryText}>
                        💰 Revenue
                      </span>
                      <span className={`${currentTheme.textColor} font-medium`}>
                        {profile.rate}
                      </span>
                    </div>
                  )}
                  <div
                    className={`flex items-center justify-between px-4 py-2 ${currentTheme.notchBg} rounded-xl border ${currentTheme.borderColor}`}
                  >
                    <span className={currentTheme.secondaryText}>✉️ Email</span>
                    <span className={currentTheme.textColor}>
                      {profile.email}
                    </span>
                  </div>
                </div>

                <button
                  className={`mt-6 w-full ${currentTheme.accentBg} text-white py-2.5 md:py-3 px-4 rounded-xl hover:opacity-90 transition flex items-center justify-center gap-2`}
                >
                  <Share className="w-4 h-4 md:w-5 md:h-5" />
                  <span>Share Profile</span>
                </button>
              </div>
            </div>
          </div>

          {/* Projects Grid - Desktop */}
          <div className="w-full md:w-2/3">
            <h2
              className={`text-xl md:text-2xl font-bold ${currentTheme.textColor} mb-4 md:mb-6`}
            >
              Journey
            </h2>
            <div className="grid gap-4 md:gap-6">
              {profile.products?.map((product) => (
                <div
                  key={product._id}
                  className={`${currentTheme.cardBg} rounded-xl md:rounded-2xl p-4 md:p-6 ${currentTheme.borderColor} hover:border-opacity-100 transition group`}
                >
                  <div className="flex items-start gap-4">
                    <div
                      className={`w-16 h-16 md:w-20 md:h-20 rounded-xl overflow-hidden flex-shrink-0 ring-1 ${currentTheme.borderColor}`}
                    >
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-grow min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <h3
                            className={`text-lg md:text-xl font-semibold ${currentTheme.textColor} mb-1 truncate`}
                          >
                            {product.name}
                          </h3>
                          <div
                            className={`flex items-center gap-2 ${currentTheme.secondaryText} text-sm mb-2`}
                          >
                            <Clock className="w-4 h-4" />
                            <span>{product.duration}</span>
                          </div>
                          <p
                            className={`text-sm md:text-base ${currentTheme.textColor} mb-3 line-clamp-2`}
                          >
                            {product.description}
                          </p>
                        </div>
                        <a
                          href={product.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`${currentTheme.notchBg} p-2 rounded-lg md:rounded-xl hover:opacity-80 transition flex-shrink-0`}
                        >
                          <ExternalLink
                            className={`w-4 h-4 md:w-5 md:h-5 ${currentTheme.textColor}`}
                          />
                        </a>
                      </div>

                      <div className="flex flex-wrap items-center gap-3">
                        <span
                          className={`px-3 py-1 rounded-full text-xs md:text-sm ${
                            product.status === "completed"
                              ? "bg-green-500/10 text-green-400"
                              : "bg-yellow-500/10 text-yellow-400"
                          }`}
                        >
                          {product.status.charAt(0).toUpperCase() +
                            product.status.slice(1)}
                        </span>

                        {product.revenue > 0 && (
                          <div className="flex items-center gap-1 text-green-400">
                            <DollarSign className="w-3 h-3 md:w-4 md:h-4" />
                            <span className="font-medium text-sm md:text-base">
                              {product.revenue}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Projects List - Mobile */}
        <div className="md:hidden">
          <h2 className={`text-xl font-bold ${currentTheme.textColor} mb-4`}>
            Journey
          </h2>
          <div className="space-y-4">
            {profile.products?.map((product) => (
              <div
                key={product._id}
                className={`${currentTheme.cardBg} rounded-xl p-4 ${currentTheme.borderColor}`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div>
                      <h3
                        className={`text-lg font-semibold ${currentTheme.textColor}`}
                      >
                        {product.name}
                      </h3>
                      <div
                        className={`flex items-center gap-1 ${currentTheme.secondaryText} text-sm`}
                      >
                        <Clock className="w-4 h-4" />
                        <span>{product.duration}</span>
                      </div>
                    </div>
                  </div>
                  <a
                    href={product.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`${currentTheme.notchBg} p-2 rounded-lg hover:opacity-80 transition`}
                  >
                    <ExternalLink
                      className={`w-5 h-5 ${currentTheme.textColor}`}
                    />
                  </a>
                </div>
                <p className={`text-sm ${currentTheme.textColor} mb-3`}>
                  {product.description}
                </p>
                <div className="flex items-center gap-3">
                  <span
                    className={`px-3 py-1 rounded-full text-xs ${
                      product.status === "completed"
                        ? "bg-green-500/10 text-green-400"
                        : "bg-yellow-500/10 text-yellow-400"
                    }`}
                  >
                    {product.status.charAt(0).toUpperCase() +
                      product.status.slice(1)}
                  </span>
                  {product.revenue > 0 && (
                    <div className="flex items-center gap-1 text-green-400">
                      <DollarSign className="w-3 h-3" />
                      <span className="font-medium text-sm">
                        {product.revenue}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer CTA */}
      <div className="md:relative bg-gradient-to-t to-transparent py-4 md:py-6">
        <div className="max-w-6xl mx-auto md:px-4">
          <div className="bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl md:rounded-2xl p-1">
            <div
              className={`${currentTheme.cardBg} rounded-lg md:rounded-xl p-4 md:p-6 flex flex-col sm:flex-row items-center justify-between gap-3 md:gap-4`}
            >
              <div className="flex items-center gap-4">
                <div className="hidden sm:flex h-10 md:h-12 w-10 md:w-12 bg-indigo-500/10 rounded-xl items-center justify-center">
                  <Sparkles className="w-5 h-5 md:w-6 md:h-6 text-indigo-400" />
                </div>
                <div>
                  <h3
                    className={`text-base md:text-lg font-semibold ${currentTheme.textColor} text-center sm:text-left`}
                  >
                    Create Your Own Profile
                  </h3>
                  <p
                    className={`text-xs md:text-sm ${currentTheme.secondaryText} text-center sm:text-left`}
                  >
                    Join thousands of entrepreneurs showcasing their journey
                  </p>
                </div>
              </div>
              <Link
                href="/"
                className={`w-full sm:w-auto ${currentTheme.accentBg} text-white px-4 md:px-6 py-2.5 md:py-3 rounded-lg md:rounded-xl font-medium hover:opacity-90 transition shadow-lg text-sm md:text-base text-center`}
              >
                Build Your Page
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Public;
