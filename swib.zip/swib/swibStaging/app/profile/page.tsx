"use client";

import { useSession } from "next-auth/react";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { signOut } from "next-auth/react";
import { LogOut, User } from "lucide-react";

export default function ProfilePage() {
  const { data: session } = useSession();

  if (!session?.user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 p-8">
      <div className="max-w-2xl mx-auto">
        <Card className="p-8">
          <div className="flex items-center space-x-8">
            <Avatar className="w-24 h-24">
              {session.user.image ? (
                <img
                  src={session.user.image}
                  alt={session.user.name || "Profile"}
                  className="w-full h-full object-cover rounded-full"
                />
              ) : (
                <User className="w-12 h-12" />
              )}
            </Avatar>
            <div className="space-y-2">
              <h1 className="text-2xl font-bold">{session.user.name}</h1>
              <p className="text-gray-600">{session.user.email}</p>
            </div>
          </div>

          <div className="mt-8">
            <Button
              variant="destructive"
              onClick={() => signOut({ callbackUrl: "/" })}
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
