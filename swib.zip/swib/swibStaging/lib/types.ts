export interface Profile {
  name: string;
  location: string;
  bio: string;
  rate: string;
  email: string;
  deploy_name?: string;
  image: string;
  theme?: string;
}

export interface ProfileContextType {
  profile: Profile;
  fetchProfile: () => Promise<void>;
  onUpdate: (data: any, image: any) => void;
  onDelete: () => Promise<void>;
  updateProfile: (field: keyof Profile, value: string) => void;
}

export interface ProfileProviderProps {
  children: React.ReactNode;
}
export interface LocalProfile {
  name: string;
  location: string;
  bio: string;
  rate: string;
  email: string;
  image: string;
}

export interface Product {
  _id?: string;
  rank: number;
  name: string;
  image: string;
  description: string;
  link: string;
  duration: string;
  status:
    | "building"
    | "active"
    | "onHold"
    | "discontinued"
    | "working"
    | "completed";
  revenue: number;
  createdAt: Date;
}

export type Theme = {
  name: string;
  borderColor: string;
  notchBg: string;
  mainBg: string;
  textColor: string;
  secondaryText: string;
  cardBg: string;
  accentBg: string;
};
